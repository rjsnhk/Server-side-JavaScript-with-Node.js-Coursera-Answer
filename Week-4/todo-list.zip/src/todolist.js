todolist = [{
    "id": 113,
    "user_id": 1,
    "title": "Complete Sprint 1",
    "due_on": "2021-11-21T00:00:00.000+05:30",
    "status": "pending"
    },{
        "id": 74,
        "user_id": 48,
        "title": "Desino coaegresco voluptatem certo accusator benevolentia.",
        "due_on": "2021-11-19T00:00:00.000+05:30",
        "status": "pending"
        },
        {
        "id": 75,
        "user_id": 49,
        "title": "Buy Tickets to the show",
        "due_on": "2021-12-11T00:00:00.000+05:30",
        "status": "completed"
        }]

module.exports = todolist